import React from "react";
import Header from "./Header";

function Contact() {
  return (
    <>
      <Header />
      <h1>This is Contact page</h1>
    </>
  );
}

export default Contact;
