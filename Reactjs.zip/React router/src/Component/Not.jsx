import React from "react";
import { useNavigate } from "react-router";

function Not() {
  const navigate = useNavigate();
  const goBack = () => {
    navigate(-1);
  };
  return (
    <>
      <h1> Page not found</h1>
      <button onClick={() => goBack()}>Go back</button>
    </>
  );
}

export default Not;
