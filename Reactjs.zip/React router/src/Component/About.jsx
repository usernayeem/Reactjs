import React from "react";
import Header from "./Header";

function About() {
  return (
    <>
      <Header />
      <h1>This is About page</h1>
    </>
  );
}

export default About;
