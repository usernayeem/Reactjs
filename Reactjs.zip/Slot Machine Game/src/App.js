import React from 'react'
import './App.css'
import SlotM from './SlotM'

function App () {
  return (
    <>
      <SlotM x='😊' y='😊' z='😊' />
      <SlotM x='😊' y='😊' z='😊' />
      <SlotM x='😊' y='🙃' z='😊' />
    </>
  )
}

export default App
