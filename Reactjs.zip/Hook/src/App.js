import React, {useState} from 'react';
import './App.css';
import Button from '@material-ui/core/Button';
import Add from '@mui/icons-material/Add';

function App() {
  const [count, updateCount] = useState(0);
  const IncCount = () => {
    updateCount(count + 1)
  }
  const DeCount = () => {
    updateCount(count - 1)
  }

  if(count < 0){
    updateCount(0)
  }
  return (
    <div>
      <h1>{count}</h1>
        <Button variant="contained" color="primary" onClick={IncCount}>
          <Add/>
        </Button>
        <Button variant="contained" color="primary" onClick={DeCount}>
          -
        </Button>
    </div>
  );
}

export default App;
