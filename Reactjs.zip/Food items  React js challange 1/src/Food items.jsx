import React from 'react'

function Food(props) {
    return (
        <>
            <ol>
                <li>{props.item}</li>
            </ol>
        </>
    )
}

export default Food
