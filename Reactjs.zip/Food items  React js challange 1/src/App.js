import React from 'react';
import './App.css';
import Food from './Food items';

function App() {
  return (
    <>
      <h1>Food</h1>
      <p>List of my favourite 5 food items</p>
      <Food item="Ice cream" />
      <Food item="Chocolate" />
      <Food item="Chips" />
      <Food item="Burger" />
      <Food item="Chicken" />
    </>
  );
}

export default App;
