import React, { createContext } from 'react';
import './App.css';
import ComponentA from './ComponentA';

const FirstName = createContext();
const LastName = createContext();
const MidName = createContext();

function App() {
  return (
    <FirstName.Provider value={'Md'}>
      <LastName.Provider value={'Nayeem'}>
        <MidName.Provider value={'Mark'}>
          <ComponentA />
        </MidName.Provider>
      </LastName.Provider>
    </FirstName.Provider>
  )
}
export default App;
export { FirstName, LastName, MidName }
