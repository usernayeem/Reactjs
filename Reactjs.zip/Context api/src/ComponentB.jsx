import React, {useContext} from 'react'
import ComponentC from './ComponentC'
import { MidName } from './App'

function ComponentB() {
  const midname = useContext(MidName);
  return (
    <div>
      <ComponentC/>
      <h1>My mid name is {midname}</h1>
    </div>
  )
}

export default ComponentB
