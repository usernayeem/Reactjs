export const question = [
    {
        id: 1,
        question: "What is an API?",
        answer: "APIs are mechanisms that enable two software components to communicate with each other using a set of definitions and protocols.",
    },
    {
        id: 2,
        question: "What does API stand for?",
        answer: "API stands for Application Programming Interface",
    },
    {
        id: 3,
        question: "What is an API with example?",
        answer: "APIs are mechanisms that enable two software components to communicate with each other using a set of definitions and protocols.",
    },
    {
        id: 4,
        question: "What are the 3 types of APIs?",
        answer: "Today, there are three categories of API protocols or architectures: REST, RPC and SOAP. These might be dubbed each with unique characteristics and tradeoffs and employed for different purposes.",
    },
    {
        id: 5,
        question: "Why an API is used?",
        answer: "APIs are needed to bring applications together in order to perform a designed function built around sharing data and executing pre-defined processes.",
    }
]