import React, {useState} from 'react'

function AccordianTemplate({question, answer}) {
    const [show, setShow] = useState(false)
    
  return (
    <div>
      <p style={{display: 'inline'}} onClick={()=> setShow(!show)}>{show? "-" : "+"}</p>
      <p style={{fontWeight:600, display:'inline'}}>{question}</p>
      {show && <p>{answer}</p>}
      
    </div>
  )
}

export default AccordianTemplate
