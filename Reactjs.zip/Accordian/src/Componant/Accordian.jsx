import React, { useState } from 'react'
import { question } from './api';
import AccordianTemplate from './AccordianTemplate';
import './Accordian.css';

export default function Accordian() {
    const [data, setData] = useState(question)
    return (
        <>
            {
                data.map((value) => {
                    const { id } = value;
                    return <AccordianTemplate key={id} {...value} />
                })
            }
        </>
    )
}
