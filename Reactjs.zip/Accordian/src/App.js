import React from 'react';
// import './App.css';
import Accordian from './Componant/Accordian';


function App() {
  return (
    <div>
      <Accordian/>
    </div>
  );
}

export default App;
