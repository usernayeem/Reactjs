import React, { useState, useEffect } from "react";
import "./App.css";

function App() {
  const [num, setNum] = useState(0);
  useEffect(() => {
    alert("Button clicked");
  });

  return (
    <>
      <button
        onClick={() => {
          setNum(num + 1);
        }}
      >
        Click me {num}
      </button>
    </>
  );
}
export default App;
