import React, { useState } from 'react'
import './App.css'

function App () {
  const [fullName, setFullname] = useState({
    fname: '',
    lname: '',
    email: ''
  })

  const inputEvent = e => {
    const { name, value } = e.target
    setFullname(preValue => {
      return {
        ...preValue,
        [name]: value
      }
      // if(name === "fname"){
      //   return{
      //     fname : value,
      //     lname : preValue.lname,
      //     email : preValue.email,
      //   }
      // }else if(name === "lname"){
      //   return{
      //     fname : preValue.fname,
      //     lname : value,
      //     email : preValue.email,
      //   }
      // }else if(name === "email"){
      //   return{
      //     fname : preValue.fname,
      //     lname : preValue.lname,
      //     email : value,
      //   }
      // }
    })
  }

  return (
    <div>
      <form>
        <h1>
          Hello. My name is {fullName.fname} {fullName.lname}
        </h1>
        <h3>My Email is {fullName.email}</h3>
        <br />
        <input
          placeholder='Enter first name'
          onChange={inputEvent}
          name='fname'
          value={fullName.fname}
        />
        <br />
        <input
          placeholder='Enter last name'
          onChange={inputEvent}
          name='lname'
          value={fullName.lname}
        />
        <br />
        <input
          placeholder='Enter email'
          onChange={inputEvent}
          name='email'
          value={fullName.email}
        />
      </form>
    </div>
  )
}

export default App
