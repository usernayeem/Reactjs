import React, { useState } from 'react';
import './App.css';

function App() {
  const [inputValue, inputValueUpdate] = useState("");
  const [item, itemUpdate] = useState([]);

  const inputEvent = (e) =>{
    inputValueUpdate(e.target.value);
  }

  const btnEvent = () =>{
    itemUpdate((preItem) =>{
      return[...preItem, inputValue]
    })
    inputValueUpdate("")
  }
  return (
    
    <div>
      <div className='card'>
        <h1>TODO APP</h1>
        <input name='input' placeholder='Enter items' onChange={inputEvent} value={inputValue}/>
        <button onClick={btnEvent}>+</button>
        <ol>
          {item.map((itemValue) =>{
            return(
            <div>
            <i style={{fontSize: 30}}>- </i>
            <li style={{display: 'inline'}}>{itemValue}</li>
            </div>
            )
          })}
        </ol>
      </div>
    </div>
  )
}

export default App
