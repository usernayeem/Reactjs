import React, { useState } from 'react';
import './App.css';
import Header from './Component/Header'
import Footer from './Component/Footer';
import CreateNote from './Component/CreateNote';
import Note from './Component/Note';

function App() {
  const [item, setItem] = useState([])
  const addNote = (note) => {
    setItem((preData) => {
      return [...preData, note]
    });
  }
  const deleteItem = (id) => {
    setItem((preData) =>
      preData.filter((valu, idex) => {
        return idex !== id;
      })
    );
  }
  return (
    <>
      <Header />
      <CreateNote passNote={addNote} />
      <div className='notes-area'>
        {item.map((val, index) => {
          return (
            <Note
              key={index}
              id={index}
              title={val.title}
              content={val.content}
              delete={deleteItem}
            />
          )
        })}
      </div>

      <Footer />
    </>
  );
}
export default App;
