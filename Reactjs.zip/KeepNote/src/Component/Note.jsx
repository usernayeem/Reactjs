import React from 'react'
import './Note.css'
import Button from '@mui/material/Button';
import DeleteForeverIcon from '@mui/icons-material/DeleteForever';

function Note(props) {
    const deleteNote = () => {
        props.delete(props.id)
    }
    return (
        <>
            <div className='note-div'>
                <h6>{props.title}</h6>
                <p>{props.content}</p>
                <Button variant="contained" className='note-btn' onClick={deleteNote}><DeleteForeverIcon /></Button>
            </div>
        </>
    )
}

export default Note
