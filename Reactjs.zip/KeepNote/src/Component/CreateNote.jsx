import { useState } from 'react';
import './CreateNote.css'
import Button from '@mui/material/Button';
import AddIcon from '@mui/icons-material/Add';

function CreateNote(props) {
  const [expand, setExpand] = useState(false);
  const [note, setNote] = useState({
    title: "",
    content: "",
  })

  const inputEvent = (e) => {
    const { name, value } = e.target
    setNote((preData) => {
      return {
        ...preData,
        [name]: value
      };
    })
  }

  const btnEvent = () => {
    props.passNote(note);
    setNote({
      title: "",
      content: "",
    })
  }

  const expandOn = () => {
    setExpand(true)
  }
  const expandOff = () => {
    setExpand(false)
  }

  return (
    <>
      <>
        <form onDoubleClick={expandOff}>
          {expand ?
            <input type="text" name='title' value={note.title} onChange={inputEvent} placeholder='Title' autoComplete='off' /> : null}

          <textarea name='content' value={note.content} onChange={inputEvent} onClick={expandOn} placeholder='Write a note'></textarea>

          {expand ? <Button className='create-note-btn' variant="contained" sx={{ color: 'orange', backgroundColor: 'white', borderColor: 'orange' }} onClick={btnEvent}><AddIcon /></Button> : null}
        </form>
      </>
    </>
  )
}

export default CreateNote
