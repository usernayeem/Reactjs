import React from 'react'
import logo from './Images/logo.png'
import './header.css'

function Header() {
  return (
    <>
      <nav className="navbar navbar-light header-orange">
        <a className="navbar-brand" href="#">
          <img src={logo} alt="" width="100" height="30" className="d-inline-block align-text-top" />
        </a>
        <div className="container-fluid">
          <h2>KEEP NOTE</h2>
        </div>
      </nav>
    </>
  )
}

export default Header
