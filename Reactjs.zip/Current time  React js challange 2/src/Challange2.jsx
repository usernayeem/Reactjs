import React, { Component } from 'react'

export default class Challange extends Component {
    constructor(props) {
        super(props);
        this.state = { d: new Date() }
    }

    tick() {
        this.setState({
            d: new Date(),
        })
    }

    componentDidMount() {
        setInterval(() => this.tick(), 1000);
    }

    render() {
        return (
            <>
                <p>{`Time is ${this.state.d.toLocaleString()}`}</p>
            </>
        );
    }
}
