import React from 'react';
import './App.css';
import Challange from './Challange2';

const d = new Date();
const date = d.getDate();
const month = d.getMonth();
const year = d.getFullYear();

function App() {
  return (
    <>
      <h1>Hello, My name is Nayem</h1>
      <p>{`Today is ${date}/${month}/${year}`}</p>
      <Challange />
    </>
  );
}

export default App;
