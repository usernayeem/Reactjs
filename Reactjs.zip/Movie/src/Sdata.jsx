const Sdata = [
  {
    id: "1",
    imgsrc: "images/download.jpg",
    title: "John Wick",
    dec: "Ex-hitman John Wick comes out of retirement",
    link: "https://www.justwatch.com/in/movie/john-wick",
  },
  {
    id: "2",
    imgsrc: "images/download2.jpg",
    title: "First Kill 2017",
    dec: "A police chief tries to solve a kidnapping.",
    link: "https://www.justwatch.com/in/movie/first-kill",
  },
];

export default Sdata;
