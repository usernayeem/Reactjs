import React from 'react';
import './App.css';
import Card from './Card';
import Sdata from './Sdata'

function ncard (val){
  return(
    <Card
    key ={val.id}
      imgsrc={val.imgsrc}
      title={val.title}
      dec={val.dec}
      link={val.link}
      />
  )
}

function App() {
  return (
    <div className='mydiv'>
      {Sdata.map(ncard)}
    </div>
  );
}

export default App;
