import React from "react";
import "./app.css";

export default function Card(props) {
  return (
    <div>
      <div className="card">
        <img src={props.imgsrc} className="card-img-top" alt="..." />
        <div className="card-body">
          <h5 className="card-title">{props.title}</h5>
          <p className="card-text lead">{props.dec}</p>
          <a href={props.link} className="btn btn-primary">
            watch
          </a>
        </div>
      </div>
    </div>
  );
}
