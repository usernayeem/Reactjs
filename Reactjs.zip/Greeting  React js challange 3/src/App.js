import React from 'react'
import './App.css'
import './index.css'

const date = new Date(2020, 5, 5, 23)
const hour = date.getHours()
const minute = date.getMinutes()

let greeting = ''

const cssStyle = {}

if (hour >= 0 && minute >= 0 && hour < 12) {
  greeting = ' Good morning 🌞'
  cssStyle.color = '#FFD700'
} else if (hour >= 12 && minute >= 0 && hour < 16) {
  greeting = ' Good noon ☀️'
  cssStyle.color = '#ffdd40'
} else if (hour >= 16 && minute >= 0 && hour < 18) {
  greeting = 'Good afternoon ☕'
  cssStyle.color = 'b#FFA500'
} else if (hour >= 18 && minute >= 0 && hour < 20) {
  greeting = 'Good evening 🌅'
  cssStyle.color = '#483D8B'
} else {
  greeting = 'Good night 🌙'
  cssStyle.color = '#191970'
}

function App () {
  return (
    <>
      <h1>
        Hello sir, <span style={cssStyle}> {greeting} </span>
      </h1>
    </>
  )
}

export default App
