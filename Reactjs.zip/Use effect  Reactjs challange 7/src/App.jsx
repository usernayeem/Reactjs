import React, { useState, useEffect } from 'react';
import './App.css';

function App() {
  const [num, setNum] = useState(0);
  useEffect(() => {
    document.title = `${num} time clicked`
  });

  // const btnEvent = () => {
  //   setNum(num + 1);
  //   document.title=`${num} time clicked`;
  // }
  return (
    <>
      <button onClick={() => { setNum(num + 1) }}>Click me {num}</button>
    </>
  )
}
export default App;