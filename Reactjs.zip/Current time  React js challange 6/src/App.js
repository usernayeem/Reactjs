import React, { useState } from 'react';
import './App.css';

function App() {
  const state = useState();
  const [time, setTime] = useState(new Date().toLocaleTimeString());
  setInterval(function () {setTime(new Date().toLocaleTimeString())}, 1000);
  

  return (
    <>
    <div className='myDiv'>
      <h1>{`Current Time is ${time}`}</h1>
    </div>
    </>
  );
}

export default App;
