import React from 'react'
import './App.css'
import add, { Sub, Mul, Div } from './Cal'

function App () {
  return (
    <>
      <li>Sum of two number is {add(40, 4)}</li>
      <li>Subtraction of two number is {Sub(40, 4)}</li>
      <li>Multiple of two number is {Mul(40, 4)}</li>
      <li>Division of two number is {Div(40, 4)}</li>
    </>
  )
}

export default App
