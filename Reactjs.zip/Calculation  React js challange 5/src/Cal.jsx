import React from "react";

function Sum(a, b) {
  return <>{a + b}</>;
}

function Sub(a, b) {
  return <>{a - b}</>;
}
function Mul(a, b) {
  return <>{a * b}</>;
}
function Div(a, b) {
  return <>{a / b}</>;
}

export default Sum;
export { Sub, Mul, Div };
