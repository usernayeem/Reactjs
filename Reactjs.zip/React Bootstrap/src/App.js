import React from 'react';
import './App.css';
import Food from './Food items';
// import "../node_modules/bootstrap/dist/css/bootstrap.min.css"

function App() {
  return (
    <div>
      <button className='btn btn-primary'>hello</button>
    </div>
  );
}

export default App;
